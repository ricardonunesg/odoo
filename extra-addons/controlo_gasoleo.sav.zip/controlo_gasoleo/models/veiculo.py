from odoo import models, fields, api

class Veiculo(models.Model):
    _name = 'gasoleo.veiculo'
    _description = 'Veículos'
    _rec_name = 'nome'   # nome interno que o Odoo usa nos dropdowns

    data_compra = fields.Date(string='Data de Compra')
    marca = fields.Char(string='Marca')
    modelo = fields.Char(string='Modelo')
    matricula = fields.Char(string='Matrícula')

    nome = fields.Char(string='Nome', required=True, index=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            marca = (vals.get('marca') or '').strip()
            modelo = (vals.get('modelo') or '').strip()
            vals['nome'] = ' '.join([x for x in [marca, modelo] if x]).strip()
        return super().create(vals_list)

    def write(self, vals):
        res = super().write(vals)
        if 'marca' in vals or 'modelo' in vals:
            for rec in self:
                rec.nome = ' '.join([x for x in [(rec.marca or '').strip(), (rec.modelo or '').strip()] if x]).strip()
        return res
