from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class Condutor(models.Model):
    _name = 'gasoleo.condutor'
    _description = 'Condutores'
    _rec_name = 'nome_completo'

    nome = fields.Char(string='Primeiro Nome', required=True)
    apelido = fields.Char(string='Último Nome', required=True)
    nome_completo = fields.Char(string='Nome', required=True, index=True)

    @api.constrains('nome', 'apelido')
    def _check_nome_apelido(self):
        for rec in self:
            if not (rec.nome or '').strip():
                raise ValidationError(_('O primeiro nome é obrigatório.'))
            if not (rec.apelido or '').strip():
                raise ValidationError(_('O último nome é obrigatório.'))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            n = (vals.get('nome') or '').strip()
            a = (vals.get('apelido') or '').strip()
            vals['nome_completo'] = f"{n} {a}".strip()
        return super().create(vals_list)

    def write(self, vals):
        res = super().write(vals)
        if 'nome' in vals or 'apelido' in vals:
            for rec in self:
                rec.nome_completo = f"{(rec.nome or '').strip()} {(rec.apelido or '').strip()}".strip()
        return res
