from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class Deposito(models.Model):
    _name = 'gasoleo.deposito'
    _description = 'Depósitos de Combustível'
    _rec_name = 'localizacao'

    localizacao = fields.Char(string='Localização', required=True)
    litros = fields.Float(string='Litros no Depósito', default=0.0)

    @api.constrains('localizacao')
    def _check_loc(self):
        for rec in self:
            if not (rec.localizacao or '').strip():
                raise ValidationError(_('A Localização é obrigatória.'))
